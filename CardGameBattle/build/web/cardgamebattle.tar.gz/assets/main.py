import pygame
import asyncio
import sys

# Khởi tạo Pygame
pygame.init()
WIDTH, HEIGHT = 1024, 768
SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("AlgoCards: Yugioh-style Battle")
FONT = pygame.font.SysFont("Arial", 24)

# Quản lý Trạng thái Game
class GameState:
    MENU = "MENU"
    BATTLE = "BATTLE"

current_state = GameState.MENU

# Quản lý Lượt đấu (Yugioh Turn Phases)
class TurnPhase:
    DRAW = "DRAW PHASE"
    STANDBY = "STANDBY PHASE"
    MAIN = "MAIN PHASE"
    BATTLE = "BATTLE PHASE"
    END = "END PHASE"

phases = [TurnPhase.DRAW, TurnPhase.STANDBY, TurnPhase.MAIN, TurnPhase.BATTLE, TurnPhase.END]
current_phase_idx = 0
current_turn = "PLAYER"  # PLAYER hoặc ENEMY

def next_phase():
    global current_phase_idx, current_turn
    current_phase_idx += 1
    if current_phase_idx >= len(phases):
        current_phase_idx = 0
        current_turn = "ENEMY" if current_turn == "PLAYER" else "PLAYER"

def render_menu():
    SCREEN.fill((30, 30, 45))
    title = FONT.render("ALGO CARDS: DATA STRUCTURES & ALGORITHMS", True, (255, 255, 255))
    btn_start = FONT.render("PRESS SPACE TO START BATTLE", True, (0, 255, 150))
    SCREEN.blit(title, (WIDTH // 2 - title.get_width() // 2, 250))
    SCREEN.blit(btn_start, (WIDTH // 2 - btn_start.get_width() // 2, 400))

def render_battle():
    SCREEN.fill((20, 25, 30))
    
    # Bàn đấu (Field Areas)
    pygame.draw.rect(SCREEN, (50, 60, 75), (100, 100, 824, 200), 2) # Enemy Field
    pygame.draw.rect(SCREEN, (50, 60, 75), (100, 468, 824, 200), 2) # Player Field
    
    # Hiển thị Thông tin Phase
    phase_text = FONT.render(f"Turn: {current_turn} | Phase: {phases[current_phase_idx]}", True, (255, 215, 0))
    hint_text = FONT.render("Press ENTER to Next Phase", True, (180, 180, 180))
    SCREEN.blit(phase_text, (50, 30))
    SCREEN.blit(hint_text, (50, 60))

async def main():
    global current_state
    clock = pygame.time.Clock()
    
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            if event.type == pygame.KEYDOWN:
                if current_state == GameState.MENU:
                    if event.key == pygame.K_SPACE:
                        current_state = GameState.BATTLE
                
                elif current_state == GameState.BATTLE:
                    if event.key == pygame.K_RETURN:
                        next_phase()

        if current_state == GameState.MENU:
            render_menu()
        elif current_state == GameState.BATTLE:
            render_battle()

        pygame.display.flip()
        clock.tick(60)
        # Bắt buộc cho pygbag / async execution
        await asyncio.sleep(0)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    asyncio.run(main())
