from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any
import sqlite3
import json

app = FastAPI(title="AlgoCards API")

# DB Initialization
def init_db():
    conn = sqlite3.connect("game.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS players (
            id TEXT PRIMARY KEY,
            username TEXT NOT NULL,
            deck TEXT NOT NULL
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS replays (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            player_id TEXT,
            actions TEXT
        )
    """)
    conn.commit()
    conn.close()

init_db()

class PlayerSchema(BaseModel):
    player_id: str
    username: str
    deck: List[str]

class ReplaySchema(BaseModel):
    player_id: str
    actions: List[Dict[str, Any]]

@app.post("/api/player")
def save_player(player: PlayerSchema):
    conn = sqlite3.connect("game.db")
    cursor = conn.cursor()
    cursor.execute(
        "INSERT OR REPLACE INTO players (id, username, deck) VALUES (?, ?, ?)",
        (player.player_id, player.username, json.dumps(player.deck))
    )
    conn.commit()
    conn.close()
    return {"status": "success", "message": "Player saved"}

@app.get("/api/player/{player_id}")
def get_player(player_id: str):
    conn = sqlite3.connect("game.db")
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, deck FROM players WHERE id = ?", (player_id,))
    row = cursor.fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Player not found")
    return {"player_id": row[0], "username": row[1], "deck": json.loads(row[2])}

@app.post("/api/replay")
def save_replay(replay: ReplaySchema):
    conn = sqlite3.connect("game.db")
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO replays (player_id, actions) VALUES (?, ?)",
        (replay.player_id, json.dumps(replay.actions))
    )
    conn.commit()
    conn.close()
    return {"status": "success", "message": "Replay saved"}